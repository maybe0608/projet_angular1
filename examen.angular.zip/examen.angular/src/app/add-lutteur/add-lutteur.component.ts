import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-lutteur',
  standalone:true,
  imports:[FormsModule,HttpClientModule,],
  templateUrl: './add-lutteur.component.html',
  styleUrls: ['./add-lutteur.component.css']
})
  export class AddLutteurComponent {
    lutteur = {
      id_equipe: '',
      pseudo: '',
      nomlutteur: '',
      taille: '',
      poids: '',
      nombrecombat: '',
      nombrevictoire: '',
      nombredefaite: '',
      photo: '', // Pour stocker le fichier photo
    };
  
    constructor(private http: HttpClient) {}
  
    valider() {
      console.log(this.lutteur);

      const formData = new FormData();
      formData.append('id_equipe', this.lutteur.id_equipe);
      formData.append('pseudo', this.lutteur.pseudo);
      formData.append('nomlutteur', this.lutteur.nomlutteur);
      formData.append('taille', this.lutteur.taille);
      formData.append('poids', this.lutteur.poids);
      formData.append('nombrecombat', this.lutteur.nombrecombat);
      formData.append('nombrevictoire', this.lutteur.nombrevictoire);
      formData.append('nombredefaite', this.lutteur.nombredefaite);
      formData.append('photo', this.lutteur.photo);
  
      this.http.post<any>('http://localhost/backend_examen/lutteurs/addlutteur.php', this.lutteur)
        .subscribe(response => {
          console.log('response = ', response);
        });
      console.log(formData);
    }
  
    handleFileInput(event: any) {
      const file = event.target.files[0];
      this.lutteur.photo = file;
    }
  }
  