import { Component } from '@angular/core';

@Component({
  selector: 'app-add-combat',
  standalone: true,
  imports: [],
  templateUrl: './add-combat.component.html',
  styleUrl: './add-combat.component.css'
})
export class AddCombatComponent {

}
