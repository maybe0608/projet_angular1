import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-lutteur',
  standalone: true,
  imports: [],
  templateUrl: './delete-lutteur.component.html',
  styleUrl: './delete-lutteur.component.css'
})
export class DeleteLutteurComponent {

}
