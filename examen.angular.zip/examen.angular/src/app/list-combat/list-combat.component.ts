import { Component } from '@angular/core';

@Component({
  selector: 'app-list-combat',
  standalone: true,
  imports: [],
  templateUrl: './list-combat.component.html',
  styleUrl: './list-combat.component.css'
})
export class ListCombatComponent {

}
