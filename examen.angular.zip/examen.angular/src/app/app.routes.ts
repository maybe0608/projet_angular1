import { Routes } from '@angular/router';
import { AddLutteurComponent } from './add-lutteur/add-lutteur.component';
import { AddCombatComponent } from './add-combat/add-combat.component';
import { ListLutteurComponent } from './list-lutteur/list-lutteur.component';
import { ListCombatComponent } from './list-combat/list-combat.component';
import { EditLutteurComponent } from './edit-lutteur/edit-lutteur.component';
import { EditCombatComponent } from './edit-combat/edit-combat.component';
import { DeleteLutteurComponent } from './delete-lutteur/delete-lutteur.component';
import { DeleteCombatComponent } from './delete-combat/delete-combat.component';
import { ArchiveLutteurComponent } from './archive-lutteur/archive-lutteur.component';
import path from 'path';
import { Component } from '@angular/core';

export const routes: Routes = [

    { path: 'add-lutteur', component: AddLutteurComponent},
    { path: 'add-combat', component: AddCombatComponent},

    { path: 'list-lutteur', component: ListLutteurComponent},
    { path: 'list-lutteur', component: ListCombatComponent},
/*
    { path: 'edit-lutteur', component: EditLutteurComponent},
    { path: 'edit-combat', component: EditCombatComponent},

    { path: 'delete-lutteur', component: DeleteLutteurComponent},
    { path: 'delete-combat', component: DeleteCombatComponent},

    { path: 'archive-combat', component: ArchiveLutteurComponent},


    
*/
];
