import { Component } from '@angular/core';

@Component({
  selector: 'app-archive-lutteur',
  standalone: true,
  imports: [],
  templateUrl: './archive-lutteur.component.html',
  styleUrl: './archive-lutteur.component.css'
})
export class ArchiveLutteurComponent {

}
