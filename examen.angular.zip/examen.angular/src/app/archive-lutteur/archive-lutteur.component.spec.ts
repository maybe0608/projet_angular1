import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveLutteurComponent } from './archive-lutteur.component';

describe('ArchiveLutteurComponent', () => {
  let component: ArchiveLutteurComponent;
  let fixture: ComponentFixture<ArchiveLutteurComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ArchiveLutteurComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ArchiveLutteurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
