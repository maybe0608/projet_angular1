import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-combat',
  standalone: true,
  imports: [],
  templateUrl: './edit-combat.component.html',
  styleUrl: './edit-combat.component.css'
})
export class EditCombatComponent {

}
