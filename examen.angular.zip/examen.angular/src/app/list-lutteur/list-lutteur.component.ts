import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-lutteur',
  standalone: true,
  imports: [HttpClientModule],
  templateUrl: './list-lutteur.component.html',
  styleUrl: './list-lutteur.component.css'
})
export class ListLutteurComponent  implements OnInit {
  lutteurs: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.getLutteurs();
  }

  getLutteurs() {
    this.http.get<any>('http://localhost/backend_examen/lutteurs/get.php')
      .subscribe(response => {
        if (response.success) {
          this.lutteurs = response.lutteurs;
        } else {
          console.error('Erreur lors de la récupération des lutteurs:', response.error);
        }
      });
  }
}