import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-combat',
  standalone: true,
  imports: [],
  templateUrl: './delete-combat.component.html',
  styleUrl: './delete-combat.component.css'
})
export class DeleteCombatComponent {

}
