import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-lutteur',
  standalone: true,
  imports: [],
  templateUrl: './edit-lutteur.component.html',
  styleUrl: './edit-lutteur.component.css'
})
export class EditLutteurComponent {

}
